from django.apps import AppConfig


class ProdappConfig(AppConfig):
    name = 'prodapp'
