from django.contrib import admin
from .models import InputImagesNew

admin.site.register(InputImagesNew)
